# Projektplanung
- Lieferando Klon
- Mehrer Restaurents
- Jedes Restaurant hat verschiedene Gerichte
- Manche Gerichte können angepasst werden. z.B. extra Toppings
- Gerichte können zum Warenkorb hinzugefügt werden
- Preis wird berechnet (mit Lieferkosten)