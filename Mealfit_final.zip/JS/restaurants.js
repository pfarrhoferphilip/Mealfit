function openRestaurant(id) {
    window.open(`./../PHP/orderPage.php?id=${id}`, "_self");
}